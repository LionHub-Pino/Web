@echo off
chcp 65001 >nul
title VOICE BOT v2.0 — SETUP

echo.
echo =================================================
echo    🎵  DISCORD VOICE BOT v2.0 — SETUP (Windows)
echo =================================================
echo.

:: ─── Bước 1: Kiểm tra Node.js ────────────────────
echo [1/5] Kiểm tra Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo     ❌ Node.js chưa được cài!
    echo     Tải tại: https://nodejs.org
    echo     Cài xong rồi chạy lại script này.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do echo     ✅ Node.js: %%v

:: ─── Bước 2: Kiểm tra Python ─────────────────────
echo.
echo [2/5] Kiểm tra Python...
where python >nul 2>&1
if %errorlevel% neq 0 (
    where python3 >nul 2>&1
    if %errorlevel% neq 0 (
        echo     ⚠️  Python chưa cài — tính năng YouTube sẽ không dùng được
        echo     Tải tại: https://www.python.org/downloads/
        set PY_CMD=
        goto :SKIP_YTDLP
    ) else (
        set PY_CMD=python3
    )
) else (
    set PY_CMD=python
)
for /f "tokens=*" %%v in ('%PY_CMD% --version 2^>^&1') do echo     ✅ %%v

:: ─── Bước 3: Cài yt-dlp ──────────────────────────
echo.
echo [3/5] Kiểm tra yt-dlp...
%PY_CMD% -m yt_dlp --version >nul 2>&1
if %errorlevel% neq 0 (
    echo     ⏳ Đang cài yt-dlp...
    %PY_CMD% -m pip install yt-dlp --quiet
    echo     ✅ yt-dlp đã cài xong!
) else (
    for /f "tokens=*" %%v in ('%PY_CMD% -m yt_dlp --version 2^>^&1') do echo     ✅ yt-dlp: %%v
)

:SKIP_YTDLP

:: ─── Bước 4: Cài npm packages ────────────────────
echo.
echo [4/5] Cài npm packages (1-2 phút)...
cd /d "%~dp0"
call npm install
if %errorlevel% neq 0 (
    echo     ❌ npm install thất bại!
    pause
    exit /b 1
)
echo     ✅ npm packages đã cài xong!

:: ─── Bước 5: Cài đặt Token ───────────────────────
echo.
echo [5/5] Cài đặt Token Discord...
if exist ".env" (
    findstr /c:"TOKEN_CỦA_BẠN_Ở_ĐÂY" .env >nul 2>&1
    if %errorlevel% neq 0 (
        echo     ✅ Token đã cài trước đó (.env tồn tại)
        goto :DONE
    )
)

echo.
echo     Điền Discord User Token để bot hoạt động:
echo     (Lấy token: F12 ^> Network ^> Filter 'api' ^> Header 'authorization')
echo.
set /p USER_TOKEN="     Dán token vào đây: "
if not "%USER_TOKEN%"=="" (
    echo DISCORD_TOKEN=%USER_TOKEN%> .env
    echo ALLOWED_USER_ID=1513846719660556399>> .env
    echo PREFIX=!>> .env
    echo     ✅ Đã lưu token vào .env
) else (
    echo     ⚠️  Bỏ qua — hãy sửa file .env hoặc index.js thủ công.
)

:DONE
echo.
echo =================================================
echo    ✅  Cài đặt hoàn tất!
echo =================================================
echo.
echo  Để chạy bot:
echo    npm start
echo.
echo  Để chạy ở chế độ nền:
echo    start /b npm start ^> bot.log 2^>^&1
echo.
echo  Gõ !help trong Discord để xem danh sách lệnh
echo.
pause
