const { Client } = require('discord.js-selfbot-v13');
const {
    joinVoiceChannel,
    createAudioPlayer,
    createAudioResource,
    getVoiceConnection,
    AudioPlayerStatus,
    StreamType,
} = require('@discordjs/voice');
// @dank074/discord-video-stream là ESM-only → dùng dynamic import()
let _streamLib = null;
let _streamer  = null;
let _currentStreamCmd  = null;   // ffmpeg FluentCommand đang chạy (để !vstop kill)
let _streamChannel     = null;   // voice channel đang stream (để rejoin sau)
async function getStreamLib() {
    if (!_streamLib) {
        try {
            _streamLib = await import('@dank074/discord-video-stream');
        } catch (e) {
            // Hiện lỗi gốc để dễ debug, không che bằng message chung chung
            const root = e?.cause?.message || e?.message || String(e);
            throw new Error(
                `❌ Không load được @dank074/discord-video-stream\n` +
                `Lỗi gốc: ${root}\n\n` +
                `Thử fix:\n` +
                `  1. rm -rf node_modules && npm install\n` +
                `  2. npm install @dank074/discord-video-stream@5 --ignore-scripts\n` +
                `  3. Đảm bảo chạy từ ~/voice-bot (không phải /storage/)`
            );
        }
    }
    return _streamLib;
}
async function getStreamer() {
    if (!_streamer) {
        const lib = await getStreamLib();
        _streamer = new lib.Streamer(client);
    }
    return _streamer;
}
const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const YTDlpWrap = require('yt-dlp-wrap').default;

// ── yt-dlp binary (tự tải, không cần Python) ──────────────
const ytDlpBin = path.join(__dirname, process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp');
let ytDlpReady = false;
async function initYtDlp() {
    if (fs.existsSync(ytDlpBin)) {
        ytDlpReady = true;
        console.log('✅ yt-dlp binary đã sẵn sàng!');
        return;
    }
    console.log('⬇️  Đang tải yt-dlp binary (lần đầu chạy)...');
    try {
        await YTDlpWrap.downloadFromGithub(ytDlpBin);
        try { fs.chmodSync(ytDlpBin, '755'); } catch (_) {}
        ytDlpReady = true;
        console.log('✅ yt-dlp binary đã được tải thành công!');
    } catch (e) {
        console.error('❌ Không tải được yt-dlp binary:', e.message);
        console.error('   Bot sẽ cần yt-dlp hoặc python3 + yt-dlp để phát nhạc.');
    }
}
initYtDlp();

// Helper: tìm kiếm YouTube qua yt-dlp (ổn định nhất, luôn được cập nhật)
async function searchYT(query, limit = 8) {
    return new Promise((resolve, reject) => {
        const args = [
            `ytsearch${limit}:${query}`,
            '--dump-json',
            '--flat-playlist',
            '--no-playlist',
            '--no-warnings',
            '--quiet',
        ];
        const proc = spawn(ytDlpBin, args);
        let out = '';
        proc.stdout.on('data', d => { out += d.toString(); });
        proc.on('close', () => {
            try {
                const results = out.trim().split('\n').filter(Boolean).map(line => {
                    const v = JSON.parse(line);
                    const sec = v.duration || 0;
                    const dur = sec ? secToTime(sec) : '?';
                    return {
                        title:       v.title || v.id,
                        url:         v.webpage_url || `https://youtu.be/${v.id}`,
                        durationRaw: dur,
                        channel:     { name: v.uploader || v.channel || '?' },
                    };
                });
                resolve(results);
            } catch (e) {
                reject(new Error('Lỗi parse kết quả tìm kiếm: ' + e.message));
            }
        });
        proc.on('error', reject);
    });
}

// Helper: lấy thông tin video qua yt-dlp (thay thế play.video_info)
async function getYtInfo(url) {
    return new Promise((resolve, reject) => {
        const args = [
            '--dump-json',
            '--no-playlist',
            '--no-warnings',
            '--quiet',
        ];
        if (fs.existsSync(YT_COOKIES_TXT)) args.push('--cookies', YT_COOKIES_TXT);
        args.push(...ytdlpProxyArgs());
        args.push(url);
        const proc = spawn(ytDlpBin, args);
        let out = '';
        proc.stdout.on('data', d => { out += d.toString(); });
        proc.on('close', () => {
            try {
                const v = JSON.parse(out.trim().split('\n')[0]);
                resolve({
                    title:    v.title || url,
                    duration: v.duration ? secToTime(v.duration) : '',
                });
            } catch (e) {
                reject(e);
            }
        });
        proc.on('error', reject);
    });
}

// =============================================
//                 CẤU HÌNH
// =============================================
const USER_TOKEN  = 'OTE1NTE2ODM3ODI2MDE1Mjgy.GBhRfg.GDkjvZkejQ47e0LUIEimxYioApdUmff218XzuA';
const ALLOWED_ID  = '1513846719660556399';
const PREFIX      = '!';

// File lưu YouTube cookie (cạnh index.js)
const YT_COOKIE_FILE     = path.join(__dirname, '.yt_cookie');
const YT_COOKIES_TXT     = path.join(__dirname, 'cookies.txt');
// Cookie string dùng cho play-dl
let ytCookieString = process.env.YT_COOKIE || '';
if (!ytCookieString && fs.existsSync(YT_COOKIE_FILE)) {
    try { ytCookieString = fs.readFileSync(YT_COOKIE_FILE, 'utf8').trim(); } catch (_) {}
}

// Proxy cho yt-dlp (vd: socks5://user:pass@host:port hoặc http://host:port)
let ytProxy = process.env.YT_PROXY || '';
// =============================================


const client = new Client({ checkUpdate: false });

// Kiểm tra cookie khi khởi động
function initCookieCheck() {
    if (fs.existsSync(YT_COOKIES_TXT)) {
        console.log('✅ YouTube cookie đã được load!');
    } else if (ytCookieString) {
        console.log('✅ YouTube cookie string đã được load!');
    } else {
        console.log('⚠️ Chưa có YouTube cookie — dùng !setcookie để set nếu cần phát nhạc YT');
    }
}
initCookieCheck();

// ── AUDIO PLAYER ──────────────────────────────
const player = createAudioPlayer({ behaviors: { noSubscriber: 'pause' } });
player.currentFile  = null;
player.currentTitle = null;
player.currentUrl   = null;
player.loopMode     = false;
player.volume       = 100;
player.startedAt    = null;

// ── STATE ─────────────────────────────────────
const queue       = [];    // [{ title, url, duration, type, file? }]
const history     = [];    // last 10 played
let   isPlaying   = false;
let   isStreaming  = false;
let   autoplay    = false;
let   lastSearchResults  = [];
let   lastVSearchResults = [];   // kết quả !vsearch (video stream)
const videoQueue         = [];   // [{ url, q, title }] — hàng đợi video stream

// =============================================
//            HELPER FUNCTIONS
// =============================================

function cleanupFile(filePath) {
    if (filePath && fs.existsSync(filePath)) {
        try { fs.unlinkSync(filePath); }
        catch (_) {}
    }
}

function getOrJoinVoice(message) {
    let channel = message.member?.voice?.channel;
    if (!channel) {
        for (const guild of client.guilds.cache.values()) {
            const m = guild.members.cache.get(ALLOWED_ID);
            if (m?.voice?.channel) { channel = m.voice.channel; break; }
        }
    }
    if (!channel) return null;

    let connection = getVoiceConnection(channel.guild.id);
    if (!connection) {
        connection = joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
            selfMute: false,
            selfDeaf: false,
        });
    }
    connection.subscribe(player);
    return { connection, channel };
}

function secToTime(sec) {
    if (!sec || isNaN(sec)) return '?:??';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return h > 0
        ? `${h}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`
        : `${m}:${s.toString().padStart(2,'0')}`;
}

function elapsed() {
    if (!player.startedAt) return '';
    const secs = Math.floor((Date.now() - player.startedAt) / 1000);
    return secToTime(secs);
}

function addHistory(item) {
    history.unshift({ ...item, playedAt: new Date().toLocaleTimeString('vi-VN') });
    if (history.length > 10) history.pop();
}

function buildQueueMsg(page = 0) {
    if (queue.length === 0) return '📭 Hàng đợi trống!';
    const PER = 10;
    const total = Math.ceil(queue.length / PER);
    const slice = queue.slice(page * PER, page * PER + PER);
    let msg = `📋 **Hàng đợi** (${queue.length} bài | trang ${page+1}/${total})\n`;
    msg += `🔁 Lặp: ${player.loopMode?'✅':'❌'}  |  🔊 Âm lượng: ${player.volume}%  |  ✨ Autoplay: ${autoplay?'✅':'❌'}\n\n`;
    slice.forEach((item, i) => {
        const n = i + page * PER;
        const icon = n === 0 && isPlaying ? '▶️' : `\`${n+1}.\``;
        msg += `${icon} **${item.title}**${item.duration ? ` [${item.duration}]` : ''}\n`;
    });
    return msg;
}

// Các site yt-dlp hỗ trợ download video
const YTDLP_SITES = [
    'youtube.com', 'youtu.be',
    'twitch.tv', 'clips.twitch.tv',
    'tiktok.com',
    'instagram.com',
    'facebook.com', 'fb.watch',
    'twitter.com', 'x.com', 't.co',
    'reddit.com', 'v.redd.it',
    'bilibili.com',
    'vimeo.com',
    'dailymotion.com',
    'streamable.com',
    'medal.tv', 'clips.medal.tv',
];

const DIRECT_VIDEO_EXT = ['.mp4', '.webm', '.mkv', '.mov', '.avi', '.flv', '.ts', '.m4v', '.mpg', '.mpeg'];

function isYouTubeUrl(str) {
    return str && (str.includes('youtube.com') || str.includes('youtu.be'));
}

function isDirectVideoUrl(str) {
    if (!str) return false;
    try {
        const u = new URL(str);
        return DIRECT_VIDEO_EXT.some(ext => u.pathname.toLowerCase().endsWith(ext));
    } catch { return false; }
}

function isPlaylistUrl(str) {
    return str && (str.includes('list=') || str.includes('/playlist'));
}

// Helper: build cookie args cho yt-dlp
function ytdlpCookieArgs() {
    if (fs.existsSync(YT_COOKIES_TXT)) return `--cookies "${YT_COOKIES_TXT}"`;
    if (!ytCookieString) return '';
    const safeVal = ytCookieString.replace(/\n/g, ' ').trim();
    return `--add-headers "Cookie:${safeVal}"`;
}

// Helper: proxy arg cho yt-dlp (dùng cho spawn array)
function ytdlpProxyArgs() {
    return ytProxy ? ['--proxy', ytProxy] : [];
}

// Helper: proxy arg dạng string (dùng cho exec)
function ytdlpProxyStr() {
    return ytProxy ? `--proxy "${ytProxy}"` : '';
}

// =============================================
//    PLAY NEXT — trái tim của bot
// =============================================
async function playNext(message) {
    if (queue.length === 0) {
        isPlaying = false;
        player.currentTitle = null;
        player.startedAt    = null;
        // Autoplay: tìm bài tương tự bài cuối
        if (autoplay && history.length > 0) {
            message.channel.send('🎲 Autoplay — đang tìm bài tiếp theo...');
            try {
                const seed    = history[0].title;
                const results = await searchYT(seed + ' lyrics', 8);
                const pick    = results.find(v => !history.some(h => h.url === v.url));
                if (pick) {
                    queue.push({ title: pick.title, url: pick.url, duration: pick.durationRaw, type: 'youtube' });
                    return playNext(message);
                }
            } catch (_) {}
        }
        return;
    }

    const item = queue[0];
    isPlaying = true;

    if (item.type === 'youtube') {
        // Dùng yt-dlp pipe — ổn định nhất, không bị break theo YouTube update
        message.channel.send(`⏳ Đang buffer **${item.title}**...`);
        try {
            const ytArgs = [
                '-f', 'bestaudio[ext=webm]/bestaudio[ext=m4a]/bestaudio/best',
                '--no-playlist',
                '--quiet',
                '--no-warnings',
                '-o', '-',
            ];
            if (fs.existsSync(YT_COOKIES_TXT)) ytArgs.push('--cookies', YT_COOKIES_TXT);
            ytArgs.push(...ytdlpProxyArgs());
            ytArgs.push(item.url);

            const ytProc = spawn(ytDlpBin, ytArgs);
            let stderrOut = '';
            ytProc.stderr.on('data', d => { stderrOut += d.toString(); });

            const resource = createAudioResource(ytProc.stdout, {
                inputType: StreamType.Arbitrary,
                inlineVolume: true,
            });
            resource.volume?.setVolumeLogarithmic(player.volume / 100);
            player.currentFile  = null;
            player.currentTitle = item.title;
            player.currentUrl   = item.url;
            player.startedAt    = Date.now();
            addHistory(item);
            player.play(resource);

            ytProc.on('close', code => {
                if (code !== 0 && stderrOut) {
                    const isAuthErr = /sign in|confirm|bot|login/i.test(stderrOut);
                    if (isAuthErr) {
                        message.channel.send(
                            `🔴 YouTube yêu cầu xác thực!\n` +
                            `> Dùng \`!setcookie <cookie_string>\` để đăng nhập.`
                        );
                    }
                }
            });

            message.channel.send(
                `🎵 Đang phát: **${item.title}**` +
                (item.duration ? ` [${item.duration}]` : '') +
                (queue.length > 1 ? `\n📋 Còn ${queue.length - 1} bài trong hàng đợi` : '')
            );
        } catch (e) {
            message.channel.send(`🔴 Lỗi tải **${item.title}** — ${e.message?.slice(0,120)}`);
            queue.shift();
            return playNext(message);
        }

    } else {
        // URL trực tiếp (file đính kèm, link mp3, v.v.)
        try {
            const resource = createAudioResource(item.url, {
                inputType: StreamType.Arbitrary,
                inlineVolume: true,
            });
            resource.volume?.setVolumeLogarithmic(player.volume / 100);
            player.currentTitle = item.title;
            player.currentUrl   = item.url;
            player.startedAt    = Date.now();
            addHistory(item);
            player.play(resource);
            message.channel.send(`🎵 Đang phát: **${item.title}**`);
        } catch (e) {
            message.channel.send(`🔴 Lỗi: ${e.message}`);
            queue.shift();
            playNext(message);
        }
    }
}

// =============================================
//            PLAYER EVENTS
// =============================================

player.on(AudioPlayerStatus.Idle, () => {
    const old = player.currentFile;
    if (!player.loopMode) {
        cleanupFile(old);
        player.currentFile = null;
        queue.shift();
    } else {
        cleanupFile(old);
        player.currentFile = null;
    }
    if (global._lastMsg) playNext(global._lastMsg);
});

// =============================================
//   runVStream — logic stream dùng chung
// =============================================
async function runVStream(message, url, q) {
    let channel = message.member?.voice?.channel;
    if (!channel) {
        for (const guild of client.guilds.cache.values()) {
            const m = guild.members.cache.get(ALLOWED_ID);
            if (m?.voice?.channel) { channel = m.voice.channel; break; }
        }
    }
    if (!channel) return message.reply('❌ Vào phòng voice trước!');

    if (isStreaming) return message.reply('⚠️ Đang có stream khác chạy! Dùng `!vstop` để dừng trước.');

    const qNum        = parseInt(q);
    const bitrateVideo    = qNum >= 1080 ? 4000 : qNum >= 720 ? 2500 : qNum >= 480 ? 1500 : 800;
    const bitrateVideoMax = qNum >= 1080 ? 5500 : qNum >= 720 ? 3500 : qNum >= 480 ? 2000 : 1200;

    async function doStream(inputPath, isTemp) {
        try {
            console.log('[STREAM] doStream start:', inputPath);
            const lib      = await getStreamLib();
            const streamer = await getStreamer();
            const { prepareStream, playStream, Encoders, Utils } = lib;

            player.stop(true);
            const existingConn = getVoiceConnection(channel.guild.id);
            if (existingConn) {
                console.log('[STREAM] destroying existing @discordjs/voice connection');
                existingConn.destroy();
                await new Promise(r => setTimeout(r, 800));
            }

            _streamChannel = channel;
            console.log('[STREAM] joinVoice guild=%s channel=%s', channel.guild.id, channel.id);
            await streamer.joinVoice(channel.guild.id, channel.id);
            console.log('[STREAM] joinVoice OK');

            const encoder = Encoders.software({ x264: { preset: 'superfast' } });
            const { command: ffmpegCmd, output } = prepareStream(inputPath, {
                encoder,
                height: qNum,
                frameRate: 30,
                bitrateVideo,
                bitrateVideoMax,
                bitrateAudio: 320,
                videoCodec: Utils.normalizeVideoCodec('H264'),
            });

            ffmpegCmd.audioFilters('volume=2');
            _currentStreamCmd = ffmpegCmd;
            ffmpegCmd.on('error', e => console.error('[STREAM ffmpeg]', e.message));
            ffmpegCmd.on('start', cmd => console.log('[STREAM ffmpeg] start:', cmd));
            message.channel.send(`▶️ Bắt đầu stream **${q}p**! (Nhấn **Go Live** trong kênh để xem)`);

            const afterStream = async (stopped = false) => {
                isStreaming = false;
                _currentStreamCmd = null;
                if (isTemp) cleanupFile(inputPath);
                try { await streamer.leaveVoice(); } catch (_) {}
                await new Promise(r => setTimeout(r, 600));
                try {
                    const vc = joinVoiceChannel({
                        channelId: _streamChannel.id,
                        guildId: _streamChannel.guild.id,
                        adapterCreator: _streamChannel.guild.voiceAdapterCreator,
                        selfMute: false,
                        selfDeaf: false,
                    });
                    vc.subscribe(player);
                    console.log('[STREAM] rejoined voice after stream');
                } catch (e) { console.warn('[STREAM] rejoin failed:', e.message); }
                _streamChannel = null;
                if (stopped) return;
                // Auto-play video tiếp theo trong hàng đợi
                if (videoQueue.length > 0) {
                    const next = videoQueue.shift();
                    message.channel.send(`⏭️ Tự phát tiếp: **${next.title || next.url}** (${next.q}p) — còn ${videoQueue.length} video trong queue`);
                    runVStream(message, next.url, next.q);
                } else {
                    message.channel.send('✅ Stream kết thúc! Bot đã rejoin voice.');
                }
            };

            playStream(output, streamer, { type: 'go-live' })
                .then(() => { console.log('[STREAM] ended normally'); afterStream(false); })
                .catch(e => {
                    console.error('[STREAM] playStream error:', e?.message);
                    afterStream(true);
                    if (e?.message !== 'Stream stopped')
                        message.channel.send(`🔴 Lỗi stream: ${e.message}`);
                });
        } catch (se) {
            console.error('[STREAM] catch error:', se?.message, se?.stack);
            isStreaming = false;
            if (isTemp) cleanupFile(inputPath);
            message.channel.send(`🔴 Lỗi khởi động stream: ${se.message}`);
        }
    }

    isStreaming = true;

    if (isDirectVideoUrl(url)) {
        message.channel.send(`📺 Đang stream file video trực tiếp (${q}p)...`);
        await doStream(url, false);
        return;
    }

    const siteName = (() => { try { return new URL(url).hostname.replace('www.',''); } catch { return 'URL'; } })();
    message.channel.send(`📺 Đang tải video từ **${siteName}** (${q}p)...`);

    const outVideo = path.join(__dirname, `stream_${Date.now()}.mp4`);
    const dlArgs = [
        '-f', `best[height<=${q}][protocol=m3u8_native]/bestvideo[height<=${q}][vcodec^=avc1]+bestaudio[ext=m4a]/bestvideo[height<=${q}]+bestaudio/best[height<=${q}]/best`,
        '--merge-output-format', 'mp4',
        '--no-playlist',
        '--newline',
        '--extractor-args', 'youtube:player_client=mweb,web_creator,default',
        '-o', outVideo,
    ];
    if (fs.existsSync(YT_COOKIES_TXT)) dlArgs.push('--cookies', YT_COOKIES_TXT);
    dlArgs.push(...ytdlpProxyArgs());
    dlArgs.push(url);

    console.log(`[YTDLP] start: ${url}`);
    const dlProc = spawn(ytDlpBin, dlArgs);
    let stderrBuf = '';
    dlProc.stdout.on('data', d => { const l = d.toString().trim(); if (l) console.log('[YTDLP]', l); });
    dlProc.stderr.on('data', d => { const l = d.toString().trim(); if (l) { console.error('[YTDLP ERR]', l); stderrBuf += l + '\n'; } });
    dlProc.on('close', async (code) => {
        if (code !== 0 || !fs.existsSync(outVideo)) {
            isStreaming = false;
            cleanupFile(outVideo);
            const isAuth    = /sign in|confirm your age|bot|login|age.restricted/i.test(stderrBuf);
            const isGeo     = /not available in your country|geo.?restrict/i.test(stderrBuf);
            const isPrivate = /private video|members.only|unavailable/i.test(stderrBuf);
            if (isAuth) {
                const hint = isYouTubeUrl(url) ? `\n> Dùng \`!setcookie <cookie>\` để đăng nhập.` : '';
                return message.channel.send(`🔴 Video yêu cầu xác thực!${hint}`);
            }
            if (isGeo)     return message.channel.send(`🔴 Video bị chặn theo vùng (geo-restricted).${ytProxy ? '' : '\n> Dùng `!setproxy <url>` để set proxy vượt rào.'}`);
            if (isPrivate) return message.channel.send('🔴 Video riêng tư hoặc không còn tồn tại.');
            const lastErr = stderrBuf.split('\n').filter(Boolean).pop()?.slice(0, 150) || '';
            return message.channel.send(
                `🔴 Không tải được video từ **${siteName}**!\n> \`${lastErr}\`\nThử: \`!vstream ${url} 480\``
            );
        }
        console.log(`[YTDLP] done: ${outVideo}`);
        await doStream(outVideo, true);
    });
}

// =============================================
//          MESSAGE EVENT — XỬ LÝ LỆNH
// =============================================

client.on('messageCreate', async (message) => {
    if (message.author.id !== ALLOWED_ID) return;
    if (!message.content?.startsWith(PREFIX)) return;

    global._lastMsg = message;

    const parts   = message.content.trim().slice(PREFIX.length).split(/ +/);
    const command = parts.shift().toLowerCase();
    const args    = parts;

    // ── !join ─────────────────────────────────────
    if (command === 'join') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước sếp ơi!');
        return message.reply(`📥 Đã vào **${res.channel.name}** (${res.channel.guild.name})`);
    }

    // ── !leave / !dc ──────────────────────────────
    if (command === 'leave' || command === 'dc') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Bot chưa ở phòng nào!');
        player.stop();
        cleanupFile(player.currentFile);
        player.currentFile = null;
        queue.length = 0;
        isPlaying = false;
        if (isStreaming) { getStreamer().then(s => s.stopStream()); isStreaming = false; }
        res.connection.destroy();
        return message.reply('📤 Đã rời phòng và dọn dẹp sạch sẽ!');
    }

    // ── !search / !tim ────────────────────────────
    if (command === 'search' || command === 'tim') {
        const query = args.join(' ');
        if (!query) return message.reply('❌ Cú pháp: `!search <tên bài>`');
        message.channel.send(`🔍 Đang tìm **${query}**...`);
        try {
            const videos = await searchYT(query, 8);
            if (!videos.length) return message.channel.send('❌ Không tìm thấy kết quả!');
            lastSearchResults = videos;
            let msg = `🔎 **Kết quả: "${query}"**\n\n`;
            videos.forEach((v, i) => {
                msg += `\`${i+1}.\` **${v.title}**\n`;
                msg += `      👤 ${v.channel?.name || '?'}  ⏱ ${v.durationRaw || '?'}\n`;
            });
            msg += `\nGõ \`!pick <số>\` để phát hoặc \`!addall\` để thêm tất cả vào hàng đợi`;
            return message.channel.send(msg);
        } catch (e) {
            return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
        }
    }

    // ── !pick <số> ────────────────────────────────
    if (command === 'pick' || command === 'chon') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || !lastSearchResults[idx])
            return message.reply('❌ Số không hợp lệ — tìm kiếm lại bằng `!search`');
        const v   = lastSearchResults[idx];
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        queue.push({ title: v.title, url: v.url, duration: v.durationRaw, type: 'youtube' });
        if (!isPlaying) playNext(message);
        else message.reply(`✅ Đã thêm vào hàng đợi: **${v.title}** [${v.durationRaw || '?'}]`);
        return;
    }

    // ── !addall — thêm hết kết quả search vào queue ─
    if (command === 'addall') {
        if (!lastSearchResults.length) return message.reply('❌ Chưa có kết quả search!');
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        lastSearchResults.forEach(v =>
            queue.push({ title: v.title, url: v.url, duration: v.durationRaw, type: 'youtube' })
        );
        message.reply(`✅ Đã thêm ${lastSearchResults.length} bài vào hàng đợi!`);
        if (!isPlaying) playNext(message);
        return;
    }

    // ── !play / !vplay ────────────────────────────
    if (command === 'play' || command === 'vplay' || command === 'p') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');

        const attachment = message.attachments.first();
        if (attachment) {
            const ok = ['.mp3','.wav','.ogg','.m4a','.flac','.webm','.opus'];
            if (!ok.some(e => attachment.name.toLowerCase().endsWith(e)))
                return message.reply('❌ File phải là file âm thanh!');
            queue.push({ title: attachment.name, url: attachment.url, type: 'url' });
            if (!isPlaying) playNext(message);
            else message.reply(`✅ Đã thêm: **${attachment.name}**`);
            return;
        }

        const input = args.join(' ');

        // Playlist YouTube
        if (isPlaylistUrl(input)) {
            message.reply('⏳ Đang lấy thông tin playlist...');
            const cookieArg = ytdlpCookieArgs();
            const infoCmd = `"${ytDlpBin}" --flat-playlist --print "%(title)s|||%(webpage_url)s|||%(duration_string)s" --no-warnings ${cookieArg} ${ytdlpProxyStr()} "${input}" 2>/dev/null`;
            exec(infoCmd, (err, stdout) => {
                if (err || !stdout.trim()) return message.channel.send('🔴 Không lấy được playlist!');
                const lines = stdout.trim().split('\n').filter(Boolean).slice(0, 50);
                lines.forEach(line => {
                    const [title, url, dur] = line.split('|||');
                    if (title && url) queue.push({ title: title.trim(), url: url.trim(), duration: dur?.trim(), type: 'youtube' });
                });
                message.channel.send(`✅ Đã thêm **${lines.length}** bài từ playlist vào hàng đợi!`);
                if (!isPlaying) playNext(message);
            });
            return;
        }

        // Link YouTube đơn — lấy title bằng yt-dlp
        if (isYouTubeUrl(input)) {
            message.reply('⏳ Đang xử lý link...');
            try {
                const info = await getYtInfo(input);
                queue.push({ title: info.title, url: input, duration: info.duration, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm vào hàng đợi: **${info.title}**${info.duration ? ` [${info.duration}]` : ''}`);
            } catch (_) {
                // Fallback: không lấy được title, vẫn thêm vào queue
                queue.push({ title: input, url: input, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm vào hàng đợi.`);
            }
            return;
        }

        // Tên bài → tự search rồi phát
        if (input) {
            message.reply(`🔍 Tìm kiếm: **${input}**...`);
            try {
                const results = await searchYT(input, 5);
                const video   = results[0];
                if (!video) return message.channel.send('❌ Không tìm thấy bài hát!');
                queue.push({ title: video.title, url: video.url, duration: video.durationRaw, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm: **${video.title}** [${video.durationRaw || '?'}]`);
            } catch (e) { message.channel.send(`🔴 Lỗi: ${e.message}`); }
            return;
        }

        return message.reply('❌ Cú pháp: `!play <tên bài / link YT / link playlist>` hoặc đính kèm file.');
    }

    // ── !playtop <bài> — thêm vào đầu queue ──────
    if (command === 'playtop' || command === 'pt') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        const input = args.join(' ');
        if (!input) return message.reply('❌ Cú pháp: `!playtop <tên bài / link>`');
        message.reply(`🔍 Tìm **${input}** để thêm lên đầu...`);
        try {
            let item;
            if (isYouTubeUrl(input)) {
                item = { title: input, url: input, type: 'youtube' };
            } else {
                const results = await searchYT(input, 3);
                const video   = results[0];
                if (!video) return message.channel.send('❌ Không tìm thấy!');
                item = { title: video.title, url: video.url, duration: video.durationRaw, type: 'youtube' };
            }
            const insertIdx = isPlaying ? 1 : 0;
            queue.splice(insertIdx, 0, item);
            if (!isPlaying) playNext(message);
            else message.channel.send(`✅ Đã thêm lên đầu hàng đợi: **${item.title}**`);
        } catch (e) { message.channel.send(`🔴 Lỗi: ${e.message}`); }
        return;
    }

    // ── !replay — phát lại bài hiện tại ──────────
    if (command === 'replay' || command === 'lailai') {
        if (!player.currentUrl && queue.length === 0)
            return message.reply('❌ Không có bài nào để phát lại!');
        const current = queue[0] || (history[0] ? { ...history[0] } : null);
        if (!current) return message.reply('❌ Không có bài để phát lại!');
        if (isPlaying) {
            player.stop();
            cleanupFile(player.currentFile);
            player.currentFile = null;
            queue.unshift({ ...current });
        }
        return playNext(message);
    }

    // ── !skip ─────────────────────────────────────
    if (command === 'skip' || command === 's') {
        if (!isPlaying && queue.length === 0) return message.reply('❌ Không có bài nào đang phát!');
        const n    = Math.max(1, parseInt(args[0]) || 1);
        const skip = Math.min(n, queue.length);
        const skippedTitle = queue[0]?.title || 'bài hiện tại';
        cleanupFile(player.currentFile);
        player.currentFile = null;
        if (!player.loopMode) queue.splice(0, skip);
        player.stop();
        message.reply(`⏭️ Đã bỏ qua ${skip > 1 ? skip + ' bài' : `**${skippedTitle}**`}`);
        if (queue.length > 0) playNext(message);
        else { isPlaying = false; message.channel.send('📭 Hết hàng đợi!'); }
        return;
    }

    // ── !stop ─────────────────────────────────────
    if (command === 'stop') {
        player.stop();
        cleanupFile(player.currentFile);
        player.currentFile = null;
        queue.length = 0;
        isPlaying = false;
        player.loopMode = false;
        player.startedAt = null;
        return message.reply('⏹️ Đã dừng nhạc và xóa toàn bộ hàng đợi!');
    }

    // ── !pause / !resume ──────────────────────────
    if (command === 'pause') {
        player.pause();
        return message.reply('⏸️ Đã tạm dừng!');
    }
    if (command === 'resume' || command === 'r') {
        player.unpause();
        return message.reply('▶️ Tiếp tục phát!');
    }

    // ── !loop ─────────────────────────────────────
    if (command === 'loop' || command === 'lap') {
        player.loopMode = !player.loopMode;
        return message.reply(player.loopMode ? '🔁 Đã bật lặp bài!' : '➡️ Đã tắt lặp bài!');
    }

    // ── !autoplay ─────────────────────────────────
    if (command === 'autoplay' || command === 'ap') {
        autoplay = !autoplay;
        return message.reply(autoplay ? '✨ Autoplay bật — sẽ tự phát bài tương tự!' : '⏹️ Autoplay tắt!');
    }

    // ── !volume <0-200> ───────────────────────────
    if (command === 'volume' || command === 'vol') {
        const vol = parseInt(args[0]);
        if (isNaN(vol) || vol < 0 || vol > 200)
            return message.reply('❌ Cú pháp: `!volume <0-200>`');
        player.volume = vol;
        // Tìm resource hiện tại để set volume ngay
        try {
            const state = player.state;
            state?.resource?.volume?.setVolumeLogarithmic(vol / 100);
        } catch (_) {}
        return message.reply(`🔊 Âm lượng: **${vol}%**`);
    }

    // ── !np — bài đang phát ───────────────────────
    if (command === 'np' || command === 'nowplaying') {
        if (!player.currentTitle)
            return message.reply('❌ Không có bài nào đang phát!');
        const elapsed_ = elapsed();
        return message.reply(
            `🎵 **Đang phát:** ${player.currentTitle}\n` +
            `⏱ Đã phát: ${elapsed_}\n` +
            `🔊 Âm lượng: ${player.volume}%  |  🔁 Loop: ${player.loopMode ? '✅' : '❌'}`
        );
    }

    // ── !queue / !q ───────────────────────────────
    if (command === 'queue' || command === 'q' || command === 'danhsach') {
        const page = Math.max(0, (parseInt(args[0]) || 1) - 1);
        return message.reply(buildQueueMsg(page));
    }

    // ── !remove <số> ──────────────────────────────
    if (command === 'remove' || command === 'xoa') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || idx < 0 || idx >= queue.length)
            return message.reply('❌ Vị trí không hợp lệ!');
        const removed = queue.splice(idx, 1)[0];
        return message.reply(`🗑️ Đã xóa: **${removed.title}**`);
    }

    // ── !move <từ> <đến> ──────────────────────────
    if (command === 'move' || command === 'mv') {
        const from = parseInt(args[0]) - 1;
        const to   = parseInt(args[1]) - 1;
        if (isNaN(from) || isNaN(to) || from < 0 || to < 0 || from >= queue.length || to >= queue.length)
            return message.reply('❌ Vị trí không hợp lệ! Cú pháp: `!move <từ> <đến>`');
        const [item] = queue.splice(from, 1);
        queue.splice(to, 0, item);
        return message.reply(`↕️ Đã di chuyển **${item.title}** từ vị trí ${from+1} → ${to+1}`);
    }

    // ── !shuffle ──────────────────────────────────
    if (command === 'shuffle' || command === 'tron') {
        if (queue.length < 2) return message.reply('❌ Cần ít nhất 2 bài trong hàng đợi!');
        const start = isPlaying ? 1 : 0;
        for (let i = queue.length - 1; i > start; i--) {
            const j = Math.floor(Math.random() * (i - start + 1)) + start;
            [queue[i], queue[j]] = [queue[j], queue[i]];
        }
        return message.reply(`🔀 Đã trộn ${queue.length - start} bài!`);
    }

    // ── !clear ────────────────────────────────────
    if (command === 'clear' || command === 'xoahet') {
        const keep = isPlaying ? [queue[0]] : [];
        queue.length = 0;
        if (keep[0]) queue.push(keep[0]);
        return message.reply(isPlaying
            ? '🗑️ Đã xóa hết hàng đợi (trừ bài đang phát)!'
            : '🗑️ Đã xóa hết hàng đợi!');
    }

    // ── !history ──────────────────────────────────
    if (command === 'history' || command === 'lichsu') {
        if (!history.length) return message.reply('📭 Chưa có lịch sử phát!');
        let msg = `📜 **Lịch sử phát gần đây:**\n\n`;
        history.forEach((h, i) => {
            msg += `\`${i+1}.\` **${h.title}** — ${h.playedAt}\n`;
        });
        return message.reply(msg);
    }

    // ── !cookie — quản lý YouTube cookie ──────────
    if (command === 'cookie') {
        if (ytCookieString) {
            return message.reply(
                `✅ **YouTube cookie đang active** (${ytCookieString.length} ký tự)\n` +
                `> Dùng \`!setcookie <cookie_mới>\` để cập nhật\n` +
                `> Dùng \`!setcookie clear\` để xóa cookie`
            );
        }
        return message.reply(
            `❌ **Chưa có YouTube cookie!**\n\n` +
            `**Cách lấy cookie (chọn 1 trong 2 cách):**\n\n` +
            `**Cách 1 — Browser Console (nhanh):**\n` +
            `1. Vào https://www.youtube.com và đăng nhập\n` +
            `2. Nhấn **F12** → tab **Console**\n` +
            `3. Gõ lệnh: \`document.cookie\`\n` +
            `4. Copy toàn bộ kết quả (dòng dài)\n` +
            `5. Gõ: \`!setcookie <dán vào đây>\`\n\n` +
            `**Cách 2 — Extension (bền hơn):**\n` +
            `1. Cài extension "Get cookies.txt LOCALLY" trên Chrome\n` +
            `2. Vào youtube.com → click extension → Export\n` +
            `3. Upload file \`cookies.txt\` vào thư mục \`voice-bot/\` trên Replit`
        );
    }

    // ── !setproxy <url | clear> ───────────────────
    if (command === 'setproxy') {
        const val = args.join(' ').trim();
        if (!val) return message.reply(
            '❌ Cú pháp:\n' +
            '• `!setproxy http://host:port` — HTTP proxy\n' +
            '• `!setproxy socks5://user:pass@host:port` — SOCKS5 proxy\n' +
            '• `!setproxy clear` — Tắt proxy\n\n' +
            `📡 Proxy hiện tại: **${ytProxy || 'Chưa set'}**`
        );
        if (val.toLowerCase() === 'clear') {
            ytProxy = '';
            return message.reply('🗑️ Đã tắt proxy!');
        }
        if (!val.startsWith('http://') && !val.startsWith('https://') && !val.startsWith('socks5://') && !val.startsWith('socks4://'))
            return message.reply('❌ Proxy phải bắt đầu bằng `http://`, `https://`, `socks5://` hoặc `socks4://`');
        ytProxy = val;
        return message.reply(`✅ Proxy đã set: \`${ytProxy}\`\nCác lệnh \`!vstream\` và playlist sẽ dùng proxy này.`);
    }

    // ── !setcookie <cookie_string | clear> hoặc đính kèm .txt/.json ──
    if (command === 'setcookie') {
        const cookieVal = args.join(' ').trim();

        // Xóa cookie
        if (cookieVal.toLowerCase() === 'clear') {
            ytCookieString = '';
            try { fs.unlinkSync(YT_COOKIE_FILE); } catch (_) {}
            return message.reply('🗑️ Đã xóa cookie!');
        }

        // Helper: chuyển mảng object cookie → "key=value; ..." string
        function objArrayToCookieStr(arr) {
            return arr
                .filter(c => c.name && c.value !== undefined)
                .map(c => `${c.name}=${c.value}`)
                .join('; ');
        }

        // Helper: parse Netscape cookies.txt → "key=value; ..." string
        function netscapeToCookieStr(text) {
            return text.split('\n')
                .filter(l => l && !l.startsWith('#'))
                .map(l => l.split('\t'))
                .filter(p => p.length >= 7)
                .map(p => `${p[5].trim()}=${p[6].trim()}`)
                .join('; ');
        }

        // Helper: mảng object cookie → Netscape format string
        function objArrayToNetscape(arr) {
            const lines = ['# Netscape HTTP Cookie File', '# Generated by setcookie', ''];
            for (const c of arr) {
                if (!c.name || c.value === undefined) continue;
                const domain    = c.domain || '.youtube.com';
                const flag      = 'TRUE';
                const path2     = c.path || '/';
                const secure    = c.secure ? 'TRUE' : 'FALSE';
                const expiry    = Math.round(c.expirationDate || 0);
                lines.push(`${domain}\t${flag}\t${path2}\t${secure}\t${expiry}\t${c.name}\t${c.value}`);
            }
            return lines.join('\n');
        }

        // Helper: lưu cả .yt_cookie và cookies.txt rồi kích hoạt
        async function applyCookie(cookieStr, netscapeStr) {
            fs.writeFileSync(YT_COOKIE_FILE, cookieStr, 'utf8');
            if (netscapeStr) fs.writeFileSync(YT_COOKIES_TXT, netscapeStr, 'utf8');
            ytCookieString = cookieStr;
            process.env.YT_COOKIE = cookieStr;
        }

        // ── Có file đính kèm? ──
        const attachment = message.attachments.first();
        if (attachment) {
            const name = attachment.name.toLowerCase();
            if (!name.endsWith('.txt') && !name.endsWith('.json'))
                return message.reply('❌ Chỉ hỗ trợ file `.txt` (Netscape / key=value) hoặc `.json` (export từ browser).');

            try {
                const res   = await fetch(attachment.url);
                const text  = await res.text();

                let cookieStr, netscapeStr;

                if (name.endsWith('.json')) {
                    // JSON array format (export từ browser extension)
                    const arr = JSON.parse(text);
                    if (!Array.isArray(arr)) return message.reply('❌ File JSON phải là mảng cookie objects.');
                    cookieStr    = objArrayToCookieStr(arr);
                    netscapeStr  = objArrayToNetscape(arr);
                } else {
                    // .txt: tự detect Netscape hay key=value string
                    if (text.trimStart().startsWith('# Netscape') || text.includes('\t')) {
                        cookieStr   = netscapeToCookieStr(text);
                        netscapeStr = text; // giữ nguyên Netscape gốc
                    } else {
                        cookieStr   = text.trim();
                        netscapeStr = null;
                    }
                }

                if (!cookieStr) return message.reply('❌ Không đọc được cookie từ file!');
                await applyCookie(cookieStr, netscapeStr);
                return message.reply(`✅ **Cookie từ file \`${attachment.name}\` đã được lưu và kích hoạt!**\nThử \`!play <tên bài>\` ngay nhé 🎵`);
            } catch (e) {
                return message.reply(`🔴 Lỗi đọc file: ${e.message}`);
            }
        }

        // ── Không có file → dùng text argument ──
        if (!cookieVal) return message.reply(
            '❌ Cú pháp:\n' +
            '• `!setcookie <cookie_string>` — paste trực tiếp\n' +
            '• `!setcookie` + đính kèm file `.txt` hoặc `.json`\n' +
            '• `!setcookie clear` — xóa cookie\n' +
            'Gõ `!cookie` để xem hướng dẫn chi tiết.'
        );

        try {
            await applyCookie(cookieVal, null);
            return message.reply('✅ **Cookie đã được lưu và kích hoạt!**\nThử `!play <tên bài>` ngay nhé 🎵');
        } catch (e) {
            return message.reply(`🔴 Lỗi khi set cookie: ${e.message}`);
        }
    }

    // ── !vsearch <từ khóa> ────────────────────────
    if (command === 'vsearch' || command === 'vs') {
        const query = args.join(' ');
        if (!query) return message.reply('❌ Cú pháp: `!vsearch <tên video> [360|480|720|1080]`');
        message.channel.send(`🔍 Đang tìm video **${query}**...`);
        try {
            const videos = await searchYT(query, 8);
            if (!videos.length) return message.channel.send('❌ Không tìm thấy kết quả!');
            lastVSearchResults = videos;
            let msg = `📺 **Kết quả video: "${query}"**\n\n`;
            videos.forEach((v, i) => {
                msg += `\`${i + 1}.\` **${v.title}**\n`;
                msg += `      👤 ${v.channel?.name || '?'}  ⏱ ${v.durationRaw || '?'}  🔗 ${v.url}\n`;
            });
            msg += `\nGõ \`!vpick <số> [360|480|720|1080]\` để stream`;
            return message.channel.send(msg);
        } catch (e) {
            return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
        }
    }

    // ── !vpick <số> [chất lượng] ─────────────────
    if (command === 'vpick' || command === 'vp') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || !lastVSearchResults[idx])
            return message.reply('❌ Số không hợp lệ — tìm kiếm lại bằng `!vsearch`');
        const v    = lastVSearchResults[idx];
        const rawQ = (args[1] || '').replace('p', '');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        await message.reply(`📺 Đã chọn: **${v.title}** (${q}p) — đang tải...`);
        return runVStream(message, v.url, q);
    }

    // ── !vstream <url> ────────────────────────────
    if (command === 'vstream' || command === 'stream') {
        const url = args[0];
        if (!url) return message.reply(
            '❌ Cú pháp: `!vstream <link> [360|480|720|1080]`\n' +
            '🌐 Hỗ trợ: YouTube · Twitch · TikTok · Instagram · Facebook · Twitter/X · Reddit · Bilibili · Vimeo · Link .mp4/.webm trực tiếp'
        );
        const rawQ = (args[1] || '').replace('p','');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        return runVStream(message, url, q);
    }

    // ── !vqadd <url/từ khóa> [chất lượng] ─────────
    if (command === 'vqadd' || command === 'vqa') {
        if (!args[0]) return message.reply('❌ Cú pháp: `!vqadd <link hoặc từ khóa> [360|480|720|1080]`');
        const rawQ = (['360','480','720','1080'].includes(args[args.length-1]?.replace('p',''))
            ? args.pop() : '720').replace('p','');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        const input = args.join(' ');
        let url = input, title = input;

        // Nếu không phải URL → tìm kiếm
        if (!input.startsWith('http')) {
            try {
                message.channel.send(`🔍 Đang tìm **${input}**...`);
                const res = await searchYT(input, 1);
                if (!res.length) return message.channel.send('❌ Không tìm thấy video!');
                url   = res[0].url;
                title = res[0].title;
            } catch (e) {
                return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
            }
        } else {
            // Lấy tiêu đề nếu là YouTube URL
            try {
                const info = await getYtInfo(url);
                title = info?.title || url;
            } catch (_) {}
        }

        if (isStreaming) {
            videoQueue.push({ url, q, title });
            return message.channel.send(`✅ Đã thêm vào queue: **${title}** (${q}p)\n📋 Vị trí: **#${videoQueue.length}** trong hàng đợi`);
        } else {
            message.channel.send(`▶️ Không có stream nào — bắt đầu phát ngay: **${title}** (${q}p)`);
            return runVStream(message, url, q);
        }
    }

    // ── !vqlist — xem hàng đợi video ─────────────
    if (command === 'vqlist' || command === 'vql') {
        if (!videoQueue.length && !isStreaming)
            return message.reply('📋 Hàng đợi video trống! Thêm bằng `!vqadd <link/tên>`');
        let msg = `📋 **HÀNG ĐỢI VIDEO STREAM** (${videoQueue.length} video)\n`;
        if (isStreaming) msg += `\n▶️ **Đang stream:** (xem bằng Go Live)\n`;
        videoQueue.forEach((v, i) => {
            msg += `\`${i + 1}.\` **${v.title || v.url}** — ${v.q}p\n`;
        });
        if (!videoQueue.length) msg += '_Trống — thêm bằng `!vqadd`_';
        return message.channel.send(msg);
    }

    // ── !vqskip — bỏ qua video hiện tại ──────────
    if (command === 'vqskip' || command === 'vqs') {
        if (!isStreaming) return message.reply('❌ Không có stream nào đang chạy!');
        if (!videoQueue.length)
            return message.reply('⚠️ Hàng đợi trống — dùng `!vstop` để dừng hẳn.');
        const next = videoQueue[0];
        message.channel.send(`⏭️ Skip! Tiếp theo: **${next.title || next.url}** (${next.q}p)`);
        // Dừng stream hiện tại — afterStream sẽ tự phát next
        if (_currentStreamCmd) { try { _currentStreamCmd.kill('SIGKILL'); } catch(_) {} }
        return;
    }

    // ── !vqclear — xóa hàng đợi video ────────────
    if (command === 'vqclear' || command === 'vqc') {
        const n = videoQueue.length;
        videoQueue.length = 0;
        return message.reply(n > 0 ? `🗑️ Đã xóa ${n} video khỏi hàng đợi.` : '📋 Hàng đợi đã trống rồi!');
    }

    // ── !vstop / !stopstream ──────────────────────
    if (command === 'vstop' || command === 'stopstream' || command === 'ss') {
        if (!isStreaming) return message.reply('❌ Không có stream nào đang chạy!');

        // Kill ffmpeg process ngay lập tức
        if (_currentStreamCmd) {
            try { _currentStreamCmd.kill('SIGKILL'); } catch (_) {}
            _currentStreamCmd = null;
        }

        const stopChannel = _streamChannel;
        isStreaming = false;
        _streamChannel = null;

        // Stop stream + rời voice
        try {
            const streamer = await getStreamer();
            streamer.stopStream();
            await new Promise(r => setTimeout(r, 400));
            await streamer.leaveVoice();
        } catch (_) {}

        // Rejoin voice bình thường
        if (stopChannel) {
            await new Promise(r => setTimeout(r, 600));
            try {
                const vc = joinVoiceChannel({
                    channelId: stopChannel.id,
                    guildId: stopChannel.guild.id,
                    adapterCreator: stopChannel.guild.voiceAdapterCreator,
                    selfMute: false,
                    selfDeaf: false,
                });
                vc.subscribe(player);
            } catch (_) {}
        }

        return message.reply('⏹️ Đã dừng stream! Bot đã rejoin voice.');
    }

    // ── !ping ─────────────────────────────────────
    if (command === 'ping') {
        const start = Date.now();
        const msg   = await message.reply('🏓 Đang đo...');
        await msg.edit(`🏓 Pong! Độ trễ: **${Date.now() - start}ms** | WS: **${client.ws.ping}ms**`);
        return;
    }

    // ── !uptime ───────────────────────────────────
    if (command === 'uptime') {
        const secs = Math.floor(process.uptime());
        const h = Math.floor(secs / 3600);
        const m = Math.floor((secs % 3600) / 60);
        const s = secs % 60;
        return message.reply(`⏰ Uptime: **${h}h ${m}m ${s}s**`);
    }

    // ── !update ───────────────────────────────────
    if (command === 'update') {
        message.reply('⏳ Đang cập nhật yt-dlp...');
        YTDlpWrap.downloadFromGithub(ytDlpBin)
            .then(() => {
                try { fs.chmodSync(ytDlpBin, '755'); } catch (_) {}
                exec(`"${ytDlpBin}" --version`, (_, ver) => {
                    message.channel.send(`✅ yt-dlp đã cập nhật lên **${ver?.trim() || 'mới nhất'}**!`);
                });
            })
            .catch(e => message.channel.send(`🔴 Lỗi cập nhật: ${e.message}`));
        return;
    }

    // ── !help ─────────────────────────────────────
    if (command === 'help' || command === 'huongdan') {
        const cookieStatus = ytCookieString ? '✅ Active' : '❌ Chưa set';
        const help = `
🤖 **VOICE BOT v2.2 — DANH SÁCH LỆNH**
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**🎵 PHÁT NHẠC**
\`!play <tên/link/playlist>\` — Phát nhạc
\`!playtop <tên/link>\` — Thêm lên đầu hàng đợi
\`!search <từ khóa>\` — Tìm kiếm (8 kết quả)
\`!pick <số>\` — Phát từ kết quả tìm kiếm
\`!addall\` — Thêm tất cả kết quả vào queue
\`!replay\` — Phát lại bài hiện tại
\`!skip [số]\` — Bỏ qua 1 hoặc nhiều bài
\`!stop\` — Dừng nhạc + xóa queue
\`!pause\` / \`!resume\` — Tạm dừng / Tiếp tục
\`!loop\` — Bật/Tắt lặp bài đang phát
\`!autoplay\` — Tự phát bài tương tự khi hết queue
\`!volume <0-200>\` — Chỉnh âm lượng
\`!np\` — Bài đang phát + trạng thái

**📋 HÀNG ĐỢI**
\`!queue [trang]\` — Xem danh sách
\`!move <từ> <đến>\` — Di chuyển vị trí bài
\`!remove <số>\` — Xóa bài khỏi hàng đợi
\`!shuffle\` — Trộn ngẫu nhiên
\`!clear\` — Xóa hết hàng đợi
\`!history\` — Lịch sử phát gần đây

**📺 STREAM VIDEO (Go Live)**
\`!vsearch <tên video>\` — Tìm video để stream (8 kết quả)
\`!vpick <số> [360|480|720|1080]\` — Stream từ kết quả tìm kiếm
\`!vstream <link> [360|480|720|1080]\` — Stream trực tiếp bằng link
\`!vstop\` / \`!stopstream\` — Dừng stream hiện tại

**📋 HÀNG ĐỢI VIDEO**
\`!vqadd <link/tên> [chất lượng]\` — Thêm vào queue (tự stream nếu rảnh)
\`!vqlist\` — Xem hàng đợi video
\`!vqskip\` — Bỏ qua video hiện tại → phát tiếp theo
\`!vqclear\` — Xóa toàn bộ hàng đợi

**🔑 YOUTUBE COOKIE** (Cookie: ${cookieStatus})
\`!cookie\` — Xem trạng thái + hướng dẫn lấy cookie
\`!setcookie <cookie_string>\` — Set cookie (paste trực tiếp)
\`!setcookie\` + file .txt/.json — Set cookie từ file đính kèm
\`!setcookie clear\` — Xóa cookie

**🌐 PROXY** (Proxy: ${ytProxy || 'Chưa set'})
\`!setproxy <url>\` — Set proxy (http:// hoặc socks5://)
\`!setproxy clear\` — Tắt proxy

**🔧 TIỆN ÍCH**
\`!join\` / \`!leave\` — Vào / Rời phòng voice
\`!ping\` — Kiểm tra độ trễ
\`!uptime\` — Thời gian bot đã chạy
\`!update\` — Cập nhật yt-dlp
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`.trim();
        return message.reply(help);
    }
});

// =============================================
//             BOT READY
// =============================================
client.on('ready', () => {
    const uptime = new Date().toLocaleString('vi-VN');
    console.log('\n═══════════════════════════════════════════');
    console.log('  🎵  VOICE BOT v2.2 — ĐÃ SẴN SÀNG!');
    console.log('═══════════════════════════════════════════');
    console.log(`  🤖  Tài khoản : ${client.user.tag}`);
    console.log(`  👑  Sếp ID    : ${ALLOWED_ID}`);
    console.log(`  🔑  Cookie YT : ${ytCookieString ? '✅ Active' : '❌ Chưa set (dùng !setcookie)'}`);
    console.log(`  ⌚  Khởi động : ${uptime}`);
    console.log('═══════════════════════════════════════════');
    console.log('\nLệnh: !play !search !pick !skip !stop !pause !resume');
    console.log('      !loop !autoplay !volume !queue !shuffle !history');
    console.log('      !playtop !move !replay !vstream !vstop !ping !uptime');
    console.log('      !cookie !setcookie\n');
});

client.on('warn',  w => console.warn('[WARN]',  w));
client.on('error', e => console.error('[ERROR]', e));

client.login(USER_TOKEN);
